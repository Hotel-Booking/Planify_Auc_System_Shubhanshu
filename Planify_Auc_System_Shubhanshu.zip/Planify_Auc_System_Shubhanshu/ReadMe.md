# Getting Started
### What this project contain?
####It is a spring boot project with mysql connectivity :
### How to run ?
1) Just need to update Username and Password of your MYSQL .
2)Manually create planify database in your MYSQL.
3) Click on Run as Spring boot Application 



