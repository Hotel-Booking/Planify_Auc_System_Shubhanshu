package com.planify.Auc_System.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="seller")
public class Seller {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	@NotNull
//	private  int  sellerId;
	
	@Id
	@Column(name="sellerName",length=24)
	@NotNull
	private  String sellerName;
	
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	@Override
	public String toString() {
		return "Seller [sellerName=" + sellerName + "]";
	}
	
	

}
