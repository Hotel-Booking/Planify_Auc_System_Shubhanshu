package com.planify.Auc_System.repo;

import com.planify.Auc_System.dto.Buyer;
import com.planify.Auc_System.dto.Seller;
import com.planify.Auc_System.dto.Auction;
import com.planify.Auc_System.dto.Bid;

public interface IAuctionRepoInterface {

	
	public boolean addBuyer(Buyer buyer);
	public boolean addSeller(Seller seller);
	public Auction createAuction(Auction auction);
	public Bid createBid(Bid bid);
	public String closeAuction(String auctionID);
	public double getProfit(String sellerName);
	public boolean withdrawBid(String buyerName, String auctionID);
}
