package com.planify.Auc_System.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="buyer")
public class Buyer {

//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
////	@NotNull
//	private  int  buyerId;
	@Id
	@Column(name="buyerName",length=24)
	@NotNull
	private  String buyerName;
	
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	@Override
	public String toString() {
		return "Buyer [buyerName=" + buyerName + "]";
	}
	
	
	
	
	
}
