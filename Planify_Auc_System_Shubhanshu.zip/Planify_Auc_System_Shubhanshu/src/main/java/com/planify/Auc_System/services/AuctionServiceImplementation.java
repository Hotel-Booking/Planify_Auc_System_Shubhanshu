package com.planify.Auc_System.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.planify.Auc_System.dto.Auction;
import com.planify.Auc_System.dto.Bid;
import com.planify.Auc_System.dto.Buyer;
import com.planify.Auc_System.dto.Seller;
import com.planify.Auc_System.repo.IAuctionRepoInterface;

@Service
public class AuctionServiceImplementation implements IAuctionServiceInterface {
	
	@Autowired
	IAuctionRepoInterface iAuctionRepoInterface;

	@Override
	public boolean addBuyer(Buyer buyer) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.addBuyer(buyer);
	}

	@Override
	public boolean addSeller(Seller seller) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.addSeller(seller);
	}

	@Override
	public Auction createAuction(Auction auction) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.createAuction(auction);
	}

	@Override
	public Bid createBid(Bid bid) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.createBid(bid);
	}

	@Override
	public String closeAuction(String auctionID) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.closeAuction(auctionID);
	}

	@Override
	public double getProfit(String sellerName) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.getProfit(sellerName);
	}

	@Override
	public boolean withdrawBid(String buyerName, String auctionID) {
		// TODO Auto-generated method stub
		return iAuctionRepoInterface.withdrawBid(buyerName,auctionID);
	}

	
}
