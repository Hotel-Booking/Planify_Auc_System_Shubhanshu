package com.planify.Auc_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.planify.Auc_System.dto.Auction;
import com.planify.Auc_System.dto.Bid;
import com.planify.Auc_System.dto.Buyer;
import com.planify.Auc_System.dto.Seller;
import com.planify.Auc_System.services.IAuctionServiceInterface;

@RestController
public class AuctionController {
	
	@Autowired
	IAuctionServiceInterface iAuctionServiceInterface;
	
	@RequestMapping(value = "/addBuyer",method = RequestMethod.POST)
	public boolean addBuyer(@RequestBody Buyer buyer) {
		System.out.println("Buyer name:"+buyer.getBuyerName());
		return iAuctionServiceInterface.addBuyer(buyer);
	}
	@RequestMapping(value = "/addSeller",method = RequestMethod.POST)
	public boolean addSeller(@RequestBody Seller seller) {
		System.out.println("Seller name:"+seller.getSellerName());
		return iAuctionServiceInterface.addSeller(seller);
	}
	@RequestMapping(value = "/createAuction",method = RequestMethod.GET)
	public void createAuction(@RequestBody Auction auction) {
		System.out.println("Auction ID:"+auction.getAuctionID()+" and Auction Participation cost:"+ auction.getParticipationCost());
		System.out.println("Highest Bid Limit:"+auction.getHighestBidLimit()+" and Lowest Bid Limit:"+ auction.getLowestBidLimit());
		System.out.println("seller name:"+auction.getSeller().getSellerName());
		iAuctionServiceInterface.createAuction(auction);
	}
	@RequestMapping(value = "/createBid",method = RequestMethod.GET)
	public void createBid(@RequestBody Bid bid) {
		System.out.println("Hello");
		System.out.println("Bid ID:"+bid.getBidId());
		System.out.println("Bid Amount:"+bid.getAmount());
		System.out.println("Bid Name:"+bid.getBuyer().getBuyerName());
		System.out.println("Auction Id::"+ bid.getAuction().getAuctionID());
		iAuctionServiceInterface.createBid(bid);
	}
	@RequestMapping(method = RequestMethod.GET, value = "/closeAuction/{auctionID}")
	public String closeAuction(@PathVariable("auctionID") String auctionID) {
		System.out.println("Auction Id:"+auctionID);
		return iAuctionServiceInterface.closeAuction(auctionID);
	}
	@RequestMapping(method = RequestMethod.GET, value = "/getProfit/{sellerName}")
	public double getProfit(@PathVariable("sellerName") String sellerName) {
		System.out.println("sellerName :"+sellerName);
		return iAuctionServiceInterface.getProfit(sellerName);
	}
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/withdrawBid/{buyerName}/{auctionID}")
	public boolean withdrawBid(@PathVariable("buyerName") String buyerName,@PathVariable("auctionID") String auctionID) {
		System.out.println("auctionID :"+auctionID+" and buyerName : "+ buyerName);
		return iAuctionServiceInterface.withdrawBid(buyerName,auctionID);
	}
}
