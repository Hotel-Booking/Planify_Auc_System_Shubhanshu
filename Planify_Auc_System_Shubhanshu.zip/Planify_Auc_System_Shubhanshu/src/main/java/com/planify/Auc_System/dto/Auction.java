package com.planify.Auc_System.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="auction")
public class Auction {

	@Id
	@Column(name="auctionID",length=2)
	@NotNull
	private  String auctionID;
	@NotNull
	private  double lowestBidLimit;
	@NotNull
	private  double highestBidLimit;
	
	@NotNull
	private  double participationCost;
	@ManyToOne(fetch = FetchType.LAZY)
	private Seller seller;
	
	
	
	public double getLowestBidLimit() {
		return lowestBidLimit;
	}

	public void setLowestBidLimit(double lowestBidLimit) {
		this.lowestBidLimit = lowestBidLimit;
	}

	public double getHighestBidLimit() {
		return highestBidLimit;
	}

	public void setHighestBidLimit(double highestBidLimit) {
		this.highestBidLimit = highestBidLimit;
	}

	public double getParticipationCost() {
		return participationCost;
	}

	public void setParticipationCost(double participationCost) {
		this.participationCost = participationCost;
	}


	
	public String getAuctionID() {
		return auctionID;
	}
	public void setAuctionID(String auctionID) {
		this.auctionID = auctionID;
	}

	
	public Seller getSeller() {
		return seller;
	}
	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	@Override
	public String toString() {
		return "Auction [auctionID=" + auctionID + ", lowestBidLimit=" + lowestBidLimit + ", highestBidLimit="
				+ highestBidLimit + ", participationCost=" + participationCost + ", seller=" + seller + "]";
	}
	
	
	
}
