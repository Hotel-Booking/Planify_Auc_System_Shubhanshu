package com.planify.Auc_System.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="bid")
public class Bid {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@NotNull
	private int bidId;
	@OneToOne()
	private  Buyer buyer;
	@ManyToOne()
	private  Auction auction;
	
	private  double amount;

	public int getBidId() {
		return bidId;
	}

	public void setBidId(int bidId) {
		this.bidId = bidId;
	}

	public Buyer getBuyer() {
		return buyer;
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	public Auction getAuction() {
		return auction;
	}

	public void setAuction(Auction auction) {
		this.auction = auction;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Bid [bidId=" + bidId + ", buyer=" + buyer + ", auction=" + auction + ", amount=" + amount + "]";
	}
	
	
}
