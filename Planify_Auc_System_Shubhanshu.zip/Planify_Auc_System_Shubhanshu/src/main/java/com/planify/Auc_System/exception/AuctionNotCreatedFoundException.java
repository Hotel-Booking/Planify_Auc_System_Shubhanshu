package com.planify.Auc_System.exception;

public class AuctionNotCreatedFoundException extends Exception{

	AuctionNotCreatedFoundException(String s){  
		  super(s);  
		 }  
}
