package com.planify.Auc_System.exception;

public class ProfitNotFoundException extends Exception {

	ProfitNotFoundException(String s){  
		  super(s);  
		 } 
}
