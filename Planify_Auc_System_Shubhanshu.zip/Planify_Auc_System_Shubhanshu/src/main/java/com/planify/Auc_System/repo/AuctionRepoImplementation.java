package com.planify.Auc_System.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.planify.Auc_System.dto.Auction;
import com.planify.Auc_System.dto.Bid;
import com.planify.Auc_System.dto.Buyer;
import com.planify.Auc_System.dto.Seller;

@Repository
@Transactional
public class AuctionRepoImplementation implements IAuctionRepoInterface{
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	static double max=0;
	static String buyerName=null;

	@Override
	public boolean addBuyer(Buyer buyer) {
		// TODO Auto-generated method stub
		
		System.out.println("adding Buyer");
		entityManager.persist(buyer);
		
		return true;
	}


	@Override
	public boolean addSeller(Seller seller) {
		// TODO Auto-generated method stub
		System.out.println("adding Seller");
		entityManager.persist(seller);
		return true;
	}


	@Override
	public Auction createAuction(Auction auction) {
		// TODO Auto-generated method stub
		
		
		
		System.out.println("Creating Auction");
		entityManager.persist(auction);
		return auction;
	}


	@Override
	public Bid createBid(Bid bid) {
		// TODO Auto-generated method stub
		String auctionID=bid.getAuction().getAuctionID();
		
		TypedQuery<Auction> query = entityManager.createQuery("select auction from Auction auction where auction.auctionID=:ad", Auction.class); 
		//"select prod from Product prod where prod.productName =:ad or prod.productBrand=:ad or prod.productType=:ad",
		query.setParameter("ad", auctionID);
		List<Auction> list = query.getResultList();
		
		if(list.get(0).getHighestBidLimit()>=bid.getAmount()&& list.get(0).getLowestBidLimit()<=bid.getAmount()) {
		System.out.println("Creating Bid");
		entityManager.persist(bid);
	}
	else {
		System.out.println("Lower or highest bid condition fail");
	}
		return bid;
	}


	@Override
	public String closeAuction(String auctionID) {
		
		// TODO Auto-generated method stub
		
		TypedQuery<Bid> query = entityManager.createQuery("select bid from Bid bid where bid.auction.auctionID=:auctionID group by bid.amount having count(bid.amount)=1 ", Bid.class); 
		query.setParameter("auctionID", auctionID);
		//select prod from Product prod where prod.productName =:ad or prod.productBrand=:ad or prod.productType=:ad
		List<Bid> list = query.getResultList();
		//select MAX(amount),buyer_buyer_name from bid where amount in(select amount  from bid group by amount having count(amount)=1);
		System.out.println(list);
		max=0;
		for(Bid index:list) {
			System.out.println("Amount"+index.getAmount()+"Buyer name"+index.getBuyer().getBuyerName());
			if(index.getAmount()>max) {
				max=index.getAmount();
				buyerName=index.getBuyer().getBuyerName();
			}
		}
		System.out.println("Bid winner"+max+" and buyer name"+buyerName);
		
		return buyerName;
	}


	@Override
	public double getProfit(String sellerName) {
		
		double profit=0.0;
		TypedQuery<Auction> query = entityManager.createQuery("select auction from Auction auction where auction.seller.sellerName =:ad", Auction.class); 
		//"select prod from Product prod where prod.productName =:ad or prod.productBrand=:ad or prod.productType=:ad",
		query.setParameter("ad", sellerName);
		List<Auction> list = query.getResultList();
		if(max>0) {
		profit=max+list.get(0).getParticipationCost()*0.2-(list.get(0).getHighestBidLimit()+list.get(0).getLowestBidLimit())/2;
		System.out.println("max"+max+"highest bid limit"+list.get(0).getHighestBidLimit()+"lowest bid limit"+list.get(0).getLowestBidLimit()+"participation cost"+list.get(0).getParticipationCost());
		System.out.println(profit);
		}
		else {
			System.out.println("Winner not announced");
		}
		return profit;
	}


	@Override
	public boolean withdrawBid(String buyerName, String auctionID) {
		// TODO Auto-generated method stub
		    Query query=entityManager.createQuery("delete from Bid bid where bid.buyer.buyerName =:bn and bid.auction.auctionID=:ai");	  
			query.setParameter("bn", buyerName);
			query.setParameter("ai", auctionID);
			int rowsDeleted= query.executeUpdate();
//		List<Bid> list = query.getResultList();
		System.out.println("Number of enteries deleted:"+ rowsDeleted);
		if(rowsDeleted>0)
		return true;
		else 
		return false;	
			
	}

}
