package com.planify.Auc_System.exception;

public class BidNotCreatedFoundException extends Exception {

	BidNotCreatedFoundException(String s){  
		  super(s);  
		 } 
}
